import { Component, OnInit, Input } from '@angular/core';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'app-mailtemplate',
  templateUrl: './mailtemplate.component.html',
  styleUrls: ['./mailtemplate.component.css']
})
export class MailtemplateComponent implements OnInit {
  mailsTo: string[] = [];
  mailsCC: string[] = [];
  mailsBCC: string[] = [];
  comments = '';
  signature = '';

  filteredMails: string[] = [];

  // tslint:disable-next-line:no-input-rename
  @Input('mailBody') mailBody: string;

  results = ['sudheer.bijinepalli@ebix.com', 'kalyan.kamesh@ebix.com', 'susmitha.d@ebix.com', 'ramesh.rao@ebix.com'];

  constructor(public msgSvc: MessageService) { }

  ngOnInit() {
    console.log('got it' + this.mailBody);
  }

  validateEmail(email: string): boolean {
    const emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
    return emailReg.test(email);
  }


  onKeyUpTo(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      // tslint:disable-next-line: deprecation
      const tokenInput = event.srcElement as any;
      if (tokenInput.value) {
        if (this.validateEmail(tokenInput.value) === true) {
          this.mailsTo.push(tokenInput.value);
          this.checkExisting('to');
        } else {
          this.msgSvc.add({
            key: 'Toast',
            sticky: true,
            severity: 'error',
            summary: 'Invalid Email(s) Found',
            detail: tokenInput.value + ' is not in valid Email format'
          });
        }
        tokenInput.value = '';
      }
    }
  }

  onKeyUpCC(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      // tslint:disable-next-line: deprecation
      const tokenInput = event.srcElement as any;
      if (tokenInput.value) {
        if (this.validateEmail(tokenInput.value) === true) {
          this.mailsCC.push(tokenInput.value);
          this.checkExisting('cc');
        } else {
          this.msgSvc.add({
            key: 'Toast',
            sticky: true,
            severity: 'error',
            summary: 'Invalid Email(s) Found',
            detail: tokenInput.value + ' is not in valid Email format'
          });
        }

        tokenInput.value = '';
      }
    }
  }

  onKeyUpBCC(event: KeyboardEvent) {
    if (event.key === 'Enter') {
      // tslint:disable-next-line: deprecation
      const tokenInput = event.srcElement as any;
      if (tokenInput.value) {
        if (this.validateEmail(tokenInput.value) === true) {
          this.mailsBCC.push(tokenInput.value);
          this.checkExisting('bcc');
        } else {
          this.msgSvc.add({
            key: 'Toast',
            sticky: true,
            severity: 'error',
            summary: 'Invalid Email(s) Found',
            detail: tokenInput.value + ' is not in valid Email format'
          });
        }
        tokenInput.value = '';
      }
    }
  }

  filterMails(event) {
    this.filteredMails = [];
    for (let i = 0; i < this.results.length; i++) {
      const mailCC = this.results[i];
      if (mailCC.toLowerCase().indexOf(event.query.toLowerCase()) === 0) {
        this.filteredMails.push(mailCC);
      }
    }
  }

  checkExisting(mode: string) {
    let errorDetail = '';
    if (mode === 'cc') {
      for (let i = 0; i < this.mailsCC.length; i++) {
        if (this.mailsTo.includes(this.mailsCC[i])) {
          const index = this.mailsCC.indexOf(this.mailsCC[i]);
          errorDetail += '' + this.mailsCC[i].toString() + ' exists in To Mail';
          this.mailsCC.splice(index, 1);
        }
      }

      for (let i = 0; i < this.mailsCC.length; i++) {
        if (this.mailsBCC.includes(this.mailsCC[i])) {
          const index = this.mailsCC.indexOf(this.mailsCC[i]);
          errorDetail += '' + this.mailsCC[i].toString() + ' exists in BCC Mail';
          this.mailsCC.splice(index, 1);
        }
      }
    } else if (mode === 'to') {
      for (let i = 0; i < this.mailsTo.length; i++) {
        if (this.mailsCC.includes(this.mailsTo[i])) {
          const index = this.mailsTo.indexOf(this.mailsTo[i]);
          errorDetail += '' + this.mailsTo[i].toString() + ' exists in CC Mail';
          this.mailsTo.splice(index, 1);
        }
      }

      for (let i = 0; i < this.mailsTo.length; i++) {
        if (this.mailsBCC.includes(this.mailsTo[i])) {
          const index = this.mailsTo.indexOf(this.mailsTo[i]);
          errorDetail += '' + this.mailsTo[i].toString() + ' exists in BCC Mail';
          this.mailsTo.splice(index, 1);
        }
      }
    } else {
      for (let i = 0; i < this.mailsBCC.length; i++) {
        if (this.mailsTo.includes(this.mailsBCC[i])) {
          const index = this.mailsBCC.indexOf(this.mailsBCC[i]);
          errorDetail += '' + this.mailsBCC[i].toString() + ' exists in To Mail';
          this.mailsBCC.splice(index, 1);
        }
      }

      for (let i = 0; i < this.mailsBCC.length; i++) {
        if (this.mailsCC.includes(this.mailsBCC[i])) {
          const index = this.mailsBCC.indexOf(this.mailsBCC[i]);
          errorDetail += '' + this.mailsBCC[i].toString() + ' exists in CC Mail';
          this.mailsBCC.splice(index, 1);
        }
      }
    }
    if (errorDetail !== '') {
      this.msgSvc.add({
        key: 'Toast',
        sticky: true,
        severity: 'error',
        summary: 'Duplicate Email(s) Found',
        detail: errorDetail
      });
    }

  }

  sendMail() {
    if (this.mailsTo.length === 0) {
      this.msgSvc.add({
        key: 'Toast',
        sticky: true,
        severity: 'error',
        summary: 'Error Sending Mail',
        detail: 'To Mail cannot be empty'
      });
    } else {
      console.log('To:' + this.mailsTo);
      console.log('CC:' + this.mailsCC);
      console.log('BCC:' + this.mailsBCC);
      console.log('Comments:' + this.comments);
      console.log('Signature:' + this.signature);
      console.log('got it' + this.mailBody);
    }
  }

}
